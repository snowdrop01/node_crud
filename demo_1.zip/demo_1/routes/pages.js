const express = require('express');
const router = express.Router();

router.get("/",(req,res)=>{
    console.log("hi runn");
    res.render("index");
})
router.get("/register",(req,res)=>{
    res.render("registration",{root:"./public"});
})
router.get("/login",(req,res)=>{
    res.render("login",{root:"./public"});
})

module.exports = router;